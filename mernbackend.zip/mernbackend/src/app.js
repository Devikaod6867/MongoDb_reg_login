require("dotenv").config()
require("./db/connection")
const express = require('express')
const app = express()
const path = require('path')
const hbs = require('hbs')
const {json} = require('express')
const bcrypt = require('bcryptjs')
const cookie = require('cookie-parser')
app.use(cookie());

// const sp = async(password)=>{
//     const ph = await bcrypt.hash(password,10)
//     console.log(ph)

//     const pm = await bcrypt.compare(password,ph)
//     console.log(pm)
// }
// sp("devika")

const Employee = require('./models/register')
const employeeRouter = require('./routers/employeeRouter')

app.use(express.json())
app.use(express.urlencoded({extended:false}))
app.use(employeeRouter)

const templatePath = path.join(__dirname,"../templates/views")
const partialsPath = path.join(__dirname,"../templates/partials")
//const staticPath = path.join(__dirname,"../public")
//console.log( path.join(__dirname,"../templates/views"))


app.set("view engine","hbs")
app.set("views",templatePath)
hbs.registerPartials(partialsPath)

//console.log(process.env.SECRET_KEY)
//app.use(express.static(staticPath))


// app.get("/",(req,res)=>{
//    // res.send("hello from devika")
//     res.render("index")
// })
// app.get("/register",(req,res)=>{
//      res.render("register")
//  })
// app.get("/login",(req,res)=>{
//     res.render("login")
// })

app.listen(8000,()=>console.log("listening to port 8000"))  