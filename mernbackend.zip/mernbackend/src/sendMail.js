const nodeMailer = require('nodemailer');

const sendEmail = async (email,subject,text) =>{
    try {
        const transporter = nodeMailer.createTransport({
                    host:process.env.HOST,
                    service: process.env.SERVICE,
                    port:587,
                    secure:true,
                    auth: {
                        user: process.env.EMAIL_USERNAME,
                        pass: process.env.EMAIL_PASSWORD,
                    },
                });
            

             await  transporter.sendMail({
                from: process.env.EMAIL_USERNAME,
                to: user.email,
                subject: subject,
                text: text
              });
                console.log("email sent");
                 
    } catch (error) {
        console.log(error,"email not sent");
    }
}

module.exports = sendEmail;