const mongoose = require('mongoose')
const employeeSchema = require('../schema/registers')
const bcrypt = require('bcryptjs')


const Register =  new mongoose.model("Register",employeeSchema) 

module.exports = Register;