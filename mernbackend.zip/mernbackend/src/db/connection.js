const mongoose = require('mongoose')

//mongoose.connect("mongodb+srv://root:root@cluster0.jhvs1ac.mongodb.net/?retryWrites=true&w=majority")
mongoose.connect("mongodb://127.0.0.1:27017/employee")
.then(()=>console.log("Connection successfull...!!!"))
.catch((err)=>console.log("no connection"))