const express = require('express')
const router = new express.Router()
const Register = require("../models/register")
const {json} = require('express')
const axios = require('axios')
const alert = require('alert')
const jwt = require('jsonwebtoken')  
const randomString = require('randomstring')
const config = require('../config/config')
const auth = require('../middleware/auth')
const sendEmail = require("../sendMail")
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { secret_jwt } = require('../config/config')
const nodemailer = require('nodemailer')

router.use(express.json())
router.use(express.urlencoded({extended:false}))
router.get("/",(req,res)=>{
    // res.send("hello from devika")
     res.render("index")
})
router.get("/secret",auth,(req,res)=>{
   // console.log(`this is the cookie::${req.cookies.jwt}`)
     res.render("secret")
})
router.get("/logout",auth,async(req,res)=>{
        try {
            console.log(req.user)
            console.log("req.user.tokens ",req.user.tokens)
            //single token 
            // res.user.tokens = req.user.tokens.filter((currentElement)=>{
            //     return currentElement.token != req.token
            // })

            req.user.tokens = []
            res.clearCookie("jwt")
            alert("logout Successfully")
            console.log("logout Successfully")
            await req.user.save()
            res.render("login")
        } catch (error) {
            console.log(error)
        }
 })
 router.get("/forgotpwd",async(req,res)=>{
  res.render("forgotpwd")
 // res.send("forgot")

})
//  router.post("/forgotpwd",async(req,res)=>{

//   const email = req.body.email;
//   const oldUser = await Register.findOne({email:email}) 
  
//   if(!oldUser){
//     console.log("user Not Found")
//     alert("user Not Found")
//   }
//   const token = crypto.randomBytes(20).toString('hex');
//   const hash = await bcrypt.hash(token, 10);

//   await Register.updateOne({ email: email }, {
//     $set: {
//       resetPasswordToken: hash,
//       resetPasswordExpires: Date.now() + 3600000, // 1 hour
//     }
//   });

//   const transporter = nodemailer.createTransport({
//     service: 'gmail',
//     auth: {
//       user: 'devikaoad6867@gmail.com',
//       pass:  'devika@123'
//     }
//   });

//   const mailOptions = {
//     from: 'oddevika123@gmail.com',
//     to: email,
//     subject: 'Reset your password',
//     text: `Click this link to reset your password: http://localhost:8000/reset-password/${token}`
//   };

//   transporter.sendMail(mailOptions, function(error, info){
//     if (error) {
//       console.log(error);
//     } else {
//       console.log('Email sent: ' + info.response);
//     }
//   });
//   alert('Check your email for a password reset link');
//   console.log('Check your email for a password reset link');
// })
// router.get('/reset-password/:token', async function(req, res) {
//   const token = req.params.token;

//   const user = await db.collection('users').findOne({ resetPasswordToken: token });

//   if (!user || user.resetPasswordExpires < Date.now()) {
//     return res.status(400).send('Invalid or expired token');
//   }

//   res.render('reset-password', { token: token });
// });

// router.post('/reset-password/:token', async function(req, res) {
//   const token = req.params.token;
//   const password = req.body.password;

//   const user = await Register.findOne({ resetPasswordToken: token });

//   if (!user || user.resetPasswordExpires < Date.now()) {
//     return res.status(400).send('Invalid or expired token');
//   }

//   const hash = await bcrypt.hash(password, 10);

//   await Register.updateOne({ resetPasswordToken: token }, {
//     $set: {
//       password: hash,
//       resetPasswordToken: null,
//       resetPasswordExpires: null,
//     }
//   });

//   alert('Password reset successfully');
//   console.log('Password reset successfully');
// })

router.post("/forgotpwd",async(req,res)=>{
 try {
  const email = req.body.email;
  const password = req.body.password
  const confirmpassword = req.body.confirmpassword 

  const oldUser  = await Register.findOne({email:email}) 
  
  if(!oldUser ){
    console.log("user Not Exists")
    alert("user Not Exists")
  }
   // await Register.updateOne({$set:{password:password,confirmpassword:confirmpassword}})
  // const token =  jwt.sign({_id:this._id.toString()}, process.env.SECRET_KEY)
       // this.tokens = this.tokens.concat({token:token})
     const secret = process.env.SECRET_KEY + oldUser .password
    const token = jwt.sign({email:oldUser .email,id:oldUser ._id},secret,{
      expiresIn:'5m'})
      const link = `http://localhost:8000/resetpwd/${oldUser ._id}/${token}`
      console.log(link)
       var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'devikaoad6867@gmail.com',
          pass: 'fivgcknfhfjnbqze'
        }
      });
      
      var mailOptions = {
        from: 'youremail@gmail.com',
        to: 'oddevika123@gmail.com',
        subject: 'Password reset',
        text: link
      };
      
      transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
 } catch (error) {
    console.log(error)
 }
})

router.get("/resetpwd/:id/:token",async(req,res)=>{
  const {id,token} = req.params
  console.log(req.params)
  
  const oldUser  = await Register.findOne({_id:id}) 
    
  if(!oldUser ){
    console.log("user Not Exists")
    res.send("user Not Exists")
  }
  const secret = process.env.SECRET_KEY + oldUser.password
  try {
      const verify = jwt.verify(token,secret)
      res.render("resetpwd",{email:verify.email,status:"not vrified"})
     // res.send("verified")
  } catch (error) {
    console.log("Not Verified",error)
    res.send("not verified")
  }
})

router.post("/resetpwd/:id/:token",async(req,res)=>{
    const {id,token} = req.params
  //  console.log(id)
  const {password,cpassword} = req.body

  
  const oldUser = await Register.findOne({_id:id}) 
  console.log(oldUser);
  if(!oldUser){
      //console.log("user Not Exists")
    //console.error(error.message);
   return res.send("user Not Exists")
  }
  const secret = process.env.SECRET_KEY + oldUser.password 

  try {
      const verify = jwt.verify(token,secret)
     if(verify){
      const updatePassword = await Register.updateOne({
        _id:id,
      },
      {
        $set:{
          password: password,
          confirmpassword:cpassword
        } 
      });
      console.log("updated successfully")
      
     }else {
      console.log(" Not VERIFIED");
     // res.send("1241434134")
     }
      // const encryptedPassword = await bcrypt.hash(password, 10);
      
      // res.render("resetpwd", {email:verify.email})
      //res.send("password Updated")
      //console.log("password Updated")
  } catch (error) {
   console.log("error")
  //  res.send(error)
  }
 })


router.get("/register",(req,res)=>{
      res.render("register")
    //  res.send("success register")
})
router.post("/register",async(req,res)=>{
    try {
        const email = req.body.email;
        const password = req.body.password;
        const cpassword = req.body.confirmpassword;
        console.log("body",req.body)   

        const oldUser = await Register.findOne({email:email})  
        if(oldUser){
            alert(`Email is already registered `)
            return res.status(200).render("register")
            // return res.status(422).json({error:"Email is already registered"})
        }else{
           
            const registerEmployee = new Register({
              
                firstname:req.body.firstname,
                lastname:req.body.lastname,
                email:req.body.email,
                gender:req.body.gender,
                phone:req.body.phone,
                age:req.body.age,
                password:password,
                confirmpassword:cpassword,
             })

             console.log(registerEmployee)

            const token = await registerEmployee.generateAuthToken()
            console.log(token)

             res.cookie("jwt",token,{
                expires:new Date(Date.now() + 30000),
                httpOnly:true
             })
            // console.log(cookie)
            const registerData =  await registerEmployee.save()
            alert("Registered successfully")
            
            console.log("registerData",registerData);
          //  res.send(registerData)
            return res.status(200).render("index")
            
            }  
    }catch(err){
        console.log(err)
    }
            
})
   
router.get("/login",(req,res)=>{
     res.render("login")
})
router.post("/login",async(req,res)=>{
    try {
        const email = req.body.email
        const password =req.body.password

        const oldUser = await Register.findOne({email:email})
       
      //  const tokenData = await create_token(registerEmployee._id)
        if(oldUser.password === password){
            alert("login Successfully")
            res.status(200).render("index")
            
             const token = await oldUser.generateAuthToken()
             console.log("login token",token)

             res.cookie("jwt",token,{
                expires:new Date(Date.now() + 600000),
                httpOnly:true,
               // secure:true
             })
             //console.log(`this is the cookie${req.cookies.jwt}`)
           // res.send("login Successfully")
        }else{
            alert("                     please enter valid username or password       ")
          //  console.log(error)s
            res.status(200).render("login")
           // res.status(400).send("please enter valid username or password")
        }
        // res.send(oldUser.password)
        // console.log(oldUser)
        //console.log(req.body.email)
        console.log(`${email} and password is ${password}`)
    } catch (error) {
        alert( "please enter valid username or password  ")
        console.log(error)
       // res.status(400).send("please enter valid username or password")
    }
})

// router.post('/forgot-password',async (req,res)=>{   
//     //router.post('/forgot-password',forgot-password)
//    try {
    
//         const empData = await Register.findOne({email:req.body.email})
//         if(empData){
//            const randomString= randomString.generate()
//            const data = await Register.updateOne({email:email},{$set:{token:randomString}})
//            res.status(200).send({success:true,msg:"please check your mail"})
//         }else{
//             res.status(404).send({success:true,msg:"This email does not exists"})
//         }
//    } catch (error) {
//     console.log(error)
//     res.status(400).send({success:false,msg:error.message})
//    }
// })
 module.exports = router;