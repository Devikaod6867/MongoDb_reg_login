const config = {
    secret_jwt:"thisismysecretkey",
    emailUser:'',
    emailPassword:'',
}
module.exports = config